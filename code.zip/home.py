import requests
import streamlit as st

def fetch_streaming_info(title):
    url = "https://streaming-availability.p.rapidapi.com/search/title"
    querystring = {
        "title": title,
        "country": "us",
        "show_type": "all",
        "output_language": "en"
    }
    headers = {
        # Add your headers here if needed
        "X-RapidAPI-Key": "Your X-RapidApi key",
        "X-RapidAPI-Host": "streaming-availability.p.rapidapi.com"
    }

    # Make an HTTP GET request
    response = requests.get(url, headers=headers, params=querystring)

    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Parse the response as JSON
        response_json = response.json()

        # Accessing the 'result' key
        results = response_json.get('result', [])

        return results

    else:
        st.error(f"Error: {response.status_code}")
        return []

def main():
    st.title("Streaming Availability Checker")

    # Take user input for the title
    title_input = st.text_input("Enter the title:")
    if not title_input:
        st.warning("Please enter a title.")
        st.stop()

    # Fetch streaming info based on user input
    results = fetch_streaming_info(title_input)

    # Display the results in Streamlit
    for result in results:
        title = result.get('title', '')
        streaming_info = result.get('streamingInfo', {}).get('us', [])

        # Check if there is any streaming information
        if streaming_info:
            st.subheader(f"Title: {title}")
            for entry in streaming_info:
                service = entry.get('service', '')
                streaming_type = entry.get('streamingType', '')
                link = entry.get('link', '')

                # Display the information in Streamlit
                st.write(f"Service: {service}")
                st.write(f"Streaming Type: {streaming_type}")
                st.write(f"Link: {link}")
            st.markdown("---")

if __name__ == "__main__":
    main()
